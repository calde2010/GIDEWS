package co.gide.traslate.entity;

import java.util.Date;

public class Empresa {

	public int getIdeDian() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getPinDian() {
		// TODO Auto-generated method stub
		return 0;
	}

	public char[] getNumReso() {
		// TODO Auto-generated method stub
		return null;
	}

	public Date getFecDesd() {
		// TODO Auto-generated method stub
		return null;
	}

	public int getRanFina() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getRanInic() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getPreRang() {
		// TODO Auto-generated method stub
		return null;
	}

	public Date getFecHast() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getNumDocu() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getClaTecn() {
		// TODO Auto-generated method stub
		return null;
	}

}
